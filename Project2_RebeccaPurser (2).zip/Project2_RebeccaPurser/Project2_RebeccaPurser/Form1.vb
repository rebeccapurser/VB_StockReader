﻿Option Strict On
Imports System.Net
Imports System.IO
Public Class Form1
    Dim wc As New WebClient
    Dim sw As StreamWriter
    Dim filename As String
    Dim source As String
    Dim t As String
    Dim w As String
    Dim h As String
    Dim n As String
    Dim currentdate As Date
    Dim xvalue As Integer
    Function buildURL(ticker As String) As String
        Dim template As String

        template = "https://finance.yahoo.com/quote/{0}"

        Return String.Format(template, ticker)
    End Function
    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click


        currentdate = Now

        'download stock information

        filename = buildURL(txtEnterTicker.Text)
        source = wc.DownloadString(filename)
        n = source

        n = TrimUpTo(n, "</path></svg></div></div></div><div")
        n = TrimUpTo(n, "data-reactid=""35"">")
        n = TrimAfter(n, "</span>", True)
        'display stock price in label
        If n = "" Then
            MessageBox.Show("Please enter a valid ticker.")
            lblStockPrice.Text = "Invalid Ticker"
        Else
            lblStockPrice.Text = "$" & n
        End If



    End Sub

    Private Sub btnViewWebsite_Click(sender As Object, e As EventArgs) Handles btnViewWebsite.Click
        sw = File.CreateText("stockinfo.html")

        sw.WriteLine("<!DOCTYPE html>")
        sw.WriteLine("<html>")
        sw.WriteLine("<head>")
        sw.WriteLine("<title>Page Title</title>")
        sw.WriteLine("<style> body {background-color: papayawhip} </style>")
        sw.WriteLine("</head>")
        sw.WriteLine("<body>")
        sw.WriteLine("<h1>Rebecca Purser - Stock and Weather Info")
        sw.WriteLine("<style> h1 {color:darkslategrey; font-family: rockwell;}</style>")
        sw.WriteLine("</h1>")
        sw.WriteLine("<p>This webpage provides the current weather information in Columbia, SC and the current NYSE price for the company you previously entered.  I created this webpage by importing data from WeatherUnderground and Yahoo Finance, parsing the source code to get the desired information, then displaying it on this page. Enjoy!")
        sw.WriteLine("<style> p, li {font-family: century gothic; font-size: 16px}</style>")
        sw.WriteLine("</p>")
        If n = "" Then
            sw.WriteLine("<h2> Please enter a valid ticker")
            sw.WriteLine("<style> h2 {color:darkslategrey; font-family: rockwell; font: 12px; text-align: center}</style>")
            sw.WriteLine("</h2>")
        Else
            sw.WriteLine("<h2> Stock Price for " & txtEnterTicker.Text.ToUpper)
            sw.WriteLine("<style> h2 {color:darkslategrey; font-family: rockwell; font: 12px; text-align: center}</style>")
            sw.WriteLine("<p>$" & n & "</p>")
            sw.WriteLine("<p>Data collected at " & currentdate.ToString("t") & " on " & currentdate.ToString("d") & " </p>")
            sw.WriteLine("</h2>")
        End If

        sw.WriteLine("<h2>Columbia Weather:")
        sw.WriteLine("<ul style = ""list-style-type: none"">")
        sw.WriteLine("<li>Temperature: " & t & "</li>")
        sw.WriteLine("<li>Condition: " & w & "</li>")
        sw.WriteLine("<li>Humidity: " & h & "%</li>")
        sw.WriteLine("</ul>")
        sw.WriteLine("</h2>")
        sw.WriteLine("</body>")
        sw.WriteLine("</html>")

        sw.Close()
        WebBrowser1.Url = New Uri("file:///" & Application.StartupPath & "\stockinfo.html")
    End Sub

    Private Sub btnGetWeather_Click(sender As Object, e As EventArgs) Handles btnGetWeather.Click
        filename = "https://www.wunderground.com/weather/us/sc/columbia"
        source = wc.DownloadString(filename)
        t = source
        'find the temperature
        t = TrimUpTo(t, "['UNIVERSAL_CACHE']")
        t = TrimUpTo(t, """temperature"":")
        t = TrimAfter(t, ",""humidity""", True)
        'display temperature in label
        lblTemp.Text = t

        'find the weather condition
        w = source
        w = TrimUpTo(w, "['UNIVERSAL_CACHE']")
        w = TrimUpTo(w, """condition"":""")
        w = TrimAfter(w, """,""temperature""", True)
        'display condition in label
        lblWeather.Text = w


        'find the humidity
        h = source
        h = TrimUpTo(h, "['UNIVERSAL_CACHE']")
        h = TrimUpTo(h, """humidity"":")
        h = TrimAfter(h, ",""wind_speed""", True)
        'display humidity in label
        lblHumidity.Text = h & "%"
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'close the application
        Me.Close()
        Application.Exit()
    End Sub

    Private Sub btnAbout_Click(sender As Object, e As EventArgs) Handles btnAbout.Click
        'display the about box
        rmpAboutBox1.Show()

    End Sub

    Private Sub btnChart_Click(sender As Object, e As EventArgs) Handles btnChart.Click
        Timer1.Interval = 10000
        Timer1.Start()
    End Sub

    Sub addData()

        Dim y As Decimal

        filename = buildURL(txtEnterTicker.Text)
        source = wc.DownloadString(filename)
        n = source

        n = TrimUpTo(n, "</path></svg></div></div></div><div")
        n = TrimUpTo(n, "data-reactid=""35"">")
        n = TrimAfter(n, "</span>", True)

        y = CDec(n)

        Chart1.Series("Series1").Points.AddXY(xvalue, y)
        xvalue = xvalue + 1

        If xvalue > Chart1.ChartAreas(0).AxisX.Maximum Then
            Chart1.ChartAreas(0).AxisX.Minimum += 1
            Chart1.ChartAreas(0).AxisX.Maximum += 1
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Chart1.ChartAreas(0).AxisX.Minimum = 0
        Chart1.ChartAreas(0).AxisX.Maximum = 100
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        addData()
    End Sub
End Class
