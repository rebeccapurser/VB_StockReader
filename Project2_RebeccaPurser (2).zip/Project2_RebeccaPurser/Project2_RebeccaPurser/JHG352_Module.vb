Imports System.IO
Module JHG352Module1

' -----------------------------------------------------------
' Public Function RemoveWhiteSpace(ByVal Str As String) As String
' Public Function returnBetween(ByRef Str As String, ByVal OpenStr As String, ByVal CloseStr As String, Optional ByVal TrimToClosestr As Boolean = False) As String
' Public Function RemoveBetween(ByVal Str As String, ByVal OpenStr As String, ByVal CloseStr As String) As String
' Public Function ToTitleCase(ByVal source As String) As String
' Public Function TrimUpTo(ByVal str As String, ByVal closestr As String, optional returnCloseStr as boolean = False) As String
' Public Function TrimAfter(ByVal str As String, ByVal startstr As String, Optional removedelim As Boolean = False) As String
' Public Function ReturnLastField(source As String, delim As String) As String
' Public Function RemoveLastField(source As String, delim As String) As String
' -----------------------------------------------------------


    Public Function RemoveWhiteSpace(ByVal Str As String) As String
        ' This function removes all white space with the exception of a single space character.
        ' Including all Tab stops, Returns, and multiple spaces.
        Dim i As Integer

        Str = Str.Trim
        For i = 1 To 31
            Str = Str.Replace(Chr(i), "")
        Next

        While Str.Contains("     ")
            Str = Str.Replace("     ", " ")
        End While

        While Str.Contains("  ")
            Str = Str.Replace("  ", " ")
        End While
        Return Str
    End Function

    Public Function returnBetween(ByRef Str As String, ByVal OpenStr As String, ByVal CloseStr As String, Optional ByVal TrimToClosestr As Boolean = False) As String
	' Given a string (str) this function returns the substring between 
	' the starting delimiter (OpenStr) and the ending delimiter (closestr).
	' You have the option to trim away the closing string (default is false)
	' ----------------------------------------------------------------------
        Dim s As String = Str
        Dim SearchStart As Integer = 0, SearchEnd As Integer = 0
        ' both start and end strings must be in string, otherwise a null string is returned. 
        Try
            SearchStart = Str.IndexOf(OpenStr) + OpenStr.Length + 1
            SearchEnd = Str.IndexOf(CloseStr, SearchStart - 1)
            If SearchEnd - SearchStart + 1 > 0 Then
                s = Mid(Str, SearchStart, SearchEnd - SearchStart + 1)
                If TrimToClosestr Then
                    Str = Str.Substring(SearchEnd)
                End If
            Else
                s = ""
            End If
        Catch ex As exception
            s = ""
        End Try
        Return s
    End Function

    Public Function RemoveBetween(ByVal Str As String, ByVal OpenStr As String, ByVal CloseStr As String) As String
        ' Custom function to return the substring between two specified characters/strings
		' ------------------------------------------------------------------------------------
        Dim i, j As Integer

        ' if openstr = "", it starts at the beginning of string.

        If OpenStr = "" Then
            If Str.Contains(CloseStr) Then Str = Str.Substring(Str.IndexOf(CloseStr))
        Else
            If CloseStr = "" Then
                Str = Str.Substring(0, OpenStr.IndexOf(OpenStr) + OpenStr.Length)
            Else
                i = Str.IndexOf(OpenStr) + OpenStr.Length
                j = Str.IndexOf(CloseStr, i)

                Str = Str.Substring(0, i) & Str.Substring(j)
            End If
        End If

        Return Str
    End Function

    Public Function ToTitleCase(ByVal source As String) As String
	' Returns the string in Title Case, with the first letter of each word capitalized
	' ---------------------------------------------------------------------------------
        Return Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(source.ToLower())
    End Function

    Public Function TrimUpTo(ByVal str As String, ByVal closestr As String, optional returnCloseStr as boolean = False) As String
        ' this removes the first part of the string
        ' if string not found, it returns a null string
		' ------------------------------------------------
        Dim i As Integer

        If closestr.Length > 0 Then
            If str.IndexOf(closestr) > -1 Then
			if returnclosestr then
				i = str.IndexOf(closestr) 
                str = str.Substring(i)
			else
				i = str.IndexOf(closestr) + closestr.Length
                str = str.Substring(i)
			end if
                
            Else
                str = ""
            End If
        End If
        Return str
    End Function
	

    Public Function TrimAfter(ByVal str As String, ByVal startstr As String, Optional removedelim As Boolean = False) As String
        ' this removes the portion of the string after the specified string
        ' if string not found, it returns the full string
		' --------------------------------------------------------------------
        Dim i As Integer
        Dim x As Integer = startstr.Length

        If removedelim Then x = 0

        If startstr.Length > 0 Then
            If str.IndexOf(startstr) > -1 Then
                i = str.IndexOf(startstr) + x
                str = str.Substring(0, i)
            Else
                ' return the whole string
            End If
        End If
        Return str
    End Function



    Public Function ReturnLastField(source As String, delim As String) As String
	' This function takes a string (source) and a delimiter (delim). 
	' It returns the last field based on the delimiter
    ' -----------------------------------------------------------	
        Dim ss() As String
        Dim d() As String = {delim}
        Dim s As String
        ss = source.Split(d, StringSplitOptions.None)
        s = ss(ss.GetUpperBound(0))

        Return s
    End Function


    Public Function RemoveLastField(source As String, delim As String) As String
	' This function takes a string (source) and a delimiter (delim). 
	' It removes the last field based on the delimiter
    ' -----------------------------------------------------------	
        Dim ss() As String
        Dim d() As String = {delim}
        Dim s As String
        ss = source.Split(d, StringSplitOptions.None)
        s = ss(ss.GetUpperBound(0))

        Return source.Substring(0, source.Length - s.Length - 1)
    End Function

End Module
